#!/usr/bin/env node
/**
 * PLAIN Language CLI
 * Run: plain <file.plain>  or  plain (REPL mode)
 */

'use strict';

const fs = require('fs');
const path = require('path');
const readline = require('readline');
const { PlainInterpreter } = require('./interpreter');

// ── ANSI colours ──────────────────────────────────────────────────────────────
const C = {
  reset: '\x1b[0m',
  bold: '\x1b[1m',
  dim: '\x1b[2m',
  red: '\x1b[91m',
  green: '\x1b[92m',
  yellow: '\x1b[93m',
  blue: '\x1b[94m',
  magenta: '\x1b[95m',
  cyan: '\x1b[96m',
  white: '\x1b[97m',
  gray: '\x1b[90m',
};

function c(color, text) {
  // Only colorize if stdout supports it
  if (!process.stdout.isTTY) return text;
  return `${C[color] || ''}${text}${C.reset}`;
}

// ── Banner ────────────────────────────────────────────────────────────────────
function printBanner() {
  console.log('');
  console.log(c('magenta', c('bold', '  ██████╗ ██╗      █████╗ ██╗███╗   ██╗')));
  console.log(c('magenta', c('bold', '  ██╔══██╗██║     ██╔══██╗██║████╗  ██║')));
  console.log(c('magenta', c('bold', '  ██████╔╝██║     ███████║██║██╔██╗ ██║')));
  console.log(c('magenta', c('bold', '  ██╔═══╝ ██║     ██╔══██║██║██║╚██╗██║')));
  console.log(c('magenta', c('bold', '  ██║     ███████╗██║  ██║██║██║ ╚████║')));
  console.log(c('magenta', c('bold', '  ╚═╝     ╚══════╝╚═╝  ╚═╝╚═╝╚═╝  ╚═══╝')));
  console.log('');
  console.log(c('cyan', '  Plain Language Programming') + c('gray', ' v1.0.0'));
  console.log(c('gray', '  A language that reads like sentences.'));
  console.log('');
}

// ── Output handler ────────────────────────────────────────────────────────────
function makeOutputFn() {
  return (type, value) => {
    switch (type) {
      case 'print':
        console.log(c('white', String(value)));
        break;
      case 'result':
        console.log(c('cyan', `  ${value}`));
        break;
      case 'error':
        console.error(c('red', `  ✖ ${value}`));
        break;
      case 'warn':
        console.warn(c('yellow', `  ⚠ ${value}`));
        break;
      case 'prompt':
        process.stdout.write(c('magenta', `  ❓ ${value} `));
        break;
      case 'table': {
        // same table logic as interpreter uses internally
        const table = value;
        if (!table.headers.length && !table.rows.length) return;
        const cols = table.headers.length || (table.rows[0]?.length ?? 0);
        const widths = Array(cols).fill(0);
        const allRows = [table.headers, ...table.rows];
        for (const row of allRows) {
          row.forEach((cell, i) => {
            const s = String(cell ?? '');
            if (s.length > widths[i]) widths[i] = s.length;
          });
        }
        const sep = '+' + widths.map(w => '-'.repeat(w + 2)).join('+') + '+';
        const fmtRow = (row, isHeader = false) =>
          '|' + row.map((cell, i) => {
            const s = String(cell ?? '').padEnd(widths[i]);
            return ` ${isHeader ? c('cyan', s) : c('white', s)} `;
          }).join(c('gray', '|')) + c('gray', '|');
        console.log(c('gray', sep));
        if (table.headers.length) {
          console.log(fmtRow(table.headers, true));
          console.log(c('gray', sep));
        }
        for (const row of table.rows) {
          const displayRow = row.map(cell =>
            typeof cell === 'number' ? (Number.isInteger(cell) ? cell : parseFloat(cell.toFixed(4))) : cell
          );
          console.log(fmtRow(displayRow));
        }
        console.log(c('gray', sep));
        break;
      }
    }
  };
}

// ── Async readline input ──────────────────────────────────────────────────────
function makeInputFn(rl) {
  return (prompt) => new Promise(resolve => {
    rl.question(c('magenta', `  ❓ ${prompt} `), resolve);
  });
}

// ── Run a file ────────────────────────────────────────────────────────────────
async function runFile(filePath) {
  const absPath = path.resolve(filePath);
  if (!fs.existsSync(absPath)) {
    console.error(c('red', `  ✖ File not found: ${absPath}`));
    process.exit(1);
  }

  const code = fs.readFileSync(absPath, 'utf-8');
  const outputFn = makeOutputFn();
  const rl = readline.createInterface({ input: process.stdin, output: process.stdout });
  const inputFn = makeInputFn(rl);

  const interp = new PlainInterpreter({ outputFn, inputFn });

  console.log(c('gray', `\n  Running: ${path.basename(absPath)}\n`));
  const startTs = Date.now();

  try {
    await interp.run(code);
    const ms = Date.now() - startTs;
    console.log(c('gray', `\n  ✓ Done in ${ms}ms`));
  } catch (err) {
    console.error(c('red', `\n  ✖ Runtime error: ${err.message}`));
    process.exitCode = 1;
  }

  rl.close();
}

// ── REPL mode ─────────────────────────────────────────────────────────────────
async function startREPL() {
  printBanner();
  console.log(c('gray', '  Type PLAIN commands, one per line. Type "exit" to quit.\n'));

  const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout,
    prompt: c('cyan', '  plain> ')
  });

  const outputFn = makeOutputFn();
  const inputFn = makeInputFn(rl);
  const interp = new PlainInterpreter({ outputFn, inputFn });

  rl.prompt();

  rl.on('line', async (line) => {
    line = line.trim();
    if (line === 'exit' || line === 'quit') {
      console.log(c('gray', '\n  Goodbye!\n'));
      process.exit(0);
    }
    if (line === 'help') {
      printHelp();
      rl.prompt();
      return;
    }
    if (line === 'clear') {
      console.clear();
      rl.prompt();
      return;
    }
    if (!line) { rl.prompt(); return; }

    try {
      await interp.run(line);
    } catch (err) {
      console.error(c('red', `  ✖ ${err.message}`));
    }
    rl.prompt();
  });

  rl.on('close', () => {
    console.log(c('gray', '\n  Goodbye!\n'));
    process.exit(0);
  });
}

function printHelp() {
  console.log('');
  console.log(c('cyan', '  PLAIN Language Quick Reference'));
  console.log(c('gray', '  ─────────────────────────────────────────────'));
  const cmds = [
    ['set X to Y', 'Store a value in a variable'],
    ['say "text"', 'Print output'],
    ['ask "question"', 'Get user input'],
    ['if ... then / end', 'Conditional block'],
    ['repeat N times / end', 'Loop N times'],
    ['count from X to Y as i / end', 'Counted loop'],
    ['for each X in Y / end', 'Loop over a list'],
    ['create list X', 'Create an empty list'],
    ['add Y to X', 'Append to list'],
    ['define step X with ../ end step', 'Create a function'],
    ['run step X with ..', 'Call a function'],
    ['give back', 'Return from function'],
    ['calculate ... and store in X', 'Math expression'],
    ['create table X', 'Create a data table'],
    ['add row ... to X', 'Add a row to a table'],
    ['show table X', 'Display a table'],
    ['fetch "url"', 'HTTP GET request'],
    ['wait N', 'Wait N seconds'],
    ['stop', 'Stop the program'],
    ['-- comment', 'Write a comment'],
  ];
  for (const [cmd, desc] of cmds) {
    console.log(`  ${c('magenta', cmd.padEnd(40))} ${c('gray', desc)}`);
  }
  console.log('');
}

// ── Entry point ───────────────────────────────────────────────────────────────
const args = process.argv.slice(2);

if (args.includes('--help') || args.includes('-h')) {
  printBanner();
  printHelp();
  process.exit(0);
} else if (args.includes('--version') || args.includes('-v')) {
  const pkg = require('../package.json');
  console.log(`plain-lang v${pkg.version}`);
  process.exit(0);
} else if (args.length > 0 && !args[0].startsWith('-')) {
  runFile(args[0]);
} else {
  startREPL();
}

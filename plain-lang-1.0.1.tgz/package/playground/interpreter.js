/**
 * PLAIN Language Interpreter — Browser Build
 * Extracted from src/interpreter.js for use in the playground.
 */

'use strict';

function tokenize(line) {
  const tokens = [];
  let i = 0;
  line = line.trimStart();
  while (i < line.length) {
    if (line[i] === '"') {
      let j = i + 1;
      while (j < line.length && line[j] !== '"') j++;
      tokens.push({ type: 'STRING', value: line.slice(i + 1, j) });
      i = j + 1; continue;
    }
    if (line[i] === '-' && line[i + 1] === '-') break;
    if (/\d/.test(line[i]) || (line[i] === '-' && /\d/.test(line[i + 1]) && tokens.length === 0)) {
      let j = i; if (line[j] === '-') j++;
      while (j < line.length && (/\d/.test(line[j]) || line[j] === '.')) j++;
      tokens.push({ type: 'NUMBER', value: parseFloat(line.slice(i, j)) });
      i = j; continue;
    }
    if (/[a-zA-Z_]/.test(line[i])) {
      let j = i;
      while (j < line.length && /[a-zA-Z0-9_]/.test(line[j])) j++;
      tokens.push({ type: 'WORD', value: line.slice(i, j) });
      i = j; continue;
    }
    if (line[i] === '>' && line[i+1] === '=') { tokens.push({ type:'OP', value:'>=' }); i+=2; continue; }
    if (line[i] === '<' && line[i+1] === '=') { tokens.push({ type:'OP', value:'<=' }); i+=2; continue; }
    if (line[i] === '!' && line[i+1] === '=') { tokens.push({ type:'OP', value:'!=' }); i+=2; continue; }
    if ('+-*/%^'.includes(line[i])) { tokens.push({ type:'OP', value:line[i] }); i++; continue; }
    if (line[i] === '>') { tokens.push({ type:'OP', value:'>' }); i++; continue; }
    if (line[i] === '<') { tokens.push({ type:'OP', value:'<' }); i++; continue; }
    if (line[i] === '=') { tokens.push({ type:'OP', value:'=' }); i++; continue; }
    if (line[i] === ',') { tokens.push({ type:'COMMA' }); i++; continue; }
    if (line[i] === '(') { tokens.push({ type:'LPAREN' }); i++; continue; }
    if (line[i] === ')') { tokens.push({ type:'RPAREN' }); i++; continue; }
    i++;
  }
  return tokens;
}

function evalExpr(tokens, vars = {}) {
  // Pre-process: replace 'count of X' sequences with the length value
  const processed = [];
  for (let i = 0; i < tokens.length; i++) {
    const lw = tokens[i].type === 'WORD' ? tokens[i].value.toLowerCase() : null;
    if (lw === 'count' && tokens[i+1]?.type === 'WORD' && tokens[i+1]?.value?.toLowerCase() === 'of' && tokens[i+2]?.type === 'WORD') {
      const listName = tokens[i+2].value.toLowerCase();
      const list = vars[listName];
      processed.push({ type: 'NUMBER', value: Array.isArray(list) ? list.length : 0 });
      i += 2; // skip 'of' and listname
      continue;
    }
    processed.push(tokens[i]);
  }

  let expr = '';
  for (const t of processed) {
    if (t.type === 'NUMBER') expr += t.value;
    else if (t.type === 'STRING') expr += JSON.stringify(t.value);
    else if (t.type === 'WORD') {
      const lw = t.value.toLowerCase();
      if (lw === 'true') expr += 'true';
      else if (lw === 'false') expr += 'false';
      else if (lw === 'and') expr += '&&';
      else if (lw === 'or') expr += '||';
      else if (lw === 'not') expr += '!';
      else { const v = vars[lw]; expr += v !== undefined ? JSON.stringify(v) : '0'; }
    } else if (t.type === 'OP') {
      if (t.value === '^') expr += '**';
      else if (t.value === '=') expr += '===';
      else if (t.value === '!=') expr += '!==';
      else expr += t.value;
    } else if (t.type === 'LPAREN') expr += '(';
    else if (t.type === 'RPAREN') expr += ')';
    expr += ' ';
  }
  try { return Function('"use strict"; return (' + expr.trim() + ')')(); }
  catch { return expr.trim(); }
}

class PlainInterpreter {
  constructor({ outputFn, inputFn } = {}) {
    this.outputFn = outputFn;
    this.inputFn = inputFn;
    this.vars = {};
    this.functions = {};
    this.tables = {};
    this.lines = [];
    this.pos = 0;
    this.returnValue = undefined;
    this.shouldReturn = false;
  }

  formatVal(v) {
    if (typeof v === 'number') return Number.isInteger(v) ? String(v) : parseFloat(v.toFixed(6)).toString();
    if (typeof v === 'boolean') return v ? 'true' : 'false';
    if (v === null || v === undefined) return '';
    return String(v);
  }

  async run(code) {
    if (code !== undefined) this.lines = code.split('\n');
    this.pos = 0;
    while (this.pos < this.lines.length) {
      if (this.shouldReturn) break;
      const line = this.lines[this.pos].trim();
      this.pos++;
      if (!line || line.startsWith('--')) continue;
      const tokens = tokenize(line);
      if (!tokens.length) continue;
      const ws = tokens.map(t => t.type === 'WORD' ? t.value.toLowerCase() : '__');

      if (ws[0] === 'define' && ws[1] === 'step') {
        const withIdx = ws.indexOf('with');
        let funcName, params = [];
        if (withIdx !== -1) {
          funcName = ws.slice(2, withIdx).join('_');
          params = tokens.slice(withIdx + 1).filter(t => t.type === 'WORD').map(t => t.value.toLowerCase());
        } else { funcName = ws.slice(2).join('_'); }
        const body = [];
        while (this.pos < this.lines.length) {
          const bl = this.lines[this.pos].trim().toLowerCase().split(/\s+/);
          if (bl[0] === 'end' && (bl[1] === 'step' || bl.length === 1)) { this.pos++; break; }
          body.push(this.lines[this.pos]); this.pos++;
        }
        this.functions[funcName] = { params, body };
        continue;
      }
      if (ws[0] === 'if' && ws.includes('then')) { await this._runIf(tokens); continue; }
      if (ws[0] === 'repeat' && ws.includes('times')) {
        const nIdx = ws.indexOf('times');
        const n = Math.floor(Number(evalExpr(tokens.slice(1, nIdx), this.vars)));
        const body = this._collectBlock();
        for (let i = 0; i < n && !this.shouldReturn; i++) await this._runBlock(body, { ...this.vars });
        continue;
      }
      if (ws[0] === 'count' && ws[1] === 'from') {
        const toIdx = ws.indexOf('to'), asIdx = ws.indexOf('as');
        const start = Number(evalExpr(tokens.slice(2, toIdx), this.vars));
        const end = Number(evalExpr(tokens.slice(toIdx+1, asIdx !== -1 ? asIdx : undefined), this.vars));
        const varName = asIdx !== -1 ? ws[asIdx+1] : 'i';
        const body = this._collectBlock();
        for (let i = start; i <= end && !this.shouldReturn; i++) {
          this.vars[varName] = i; await this._runBlock(body, { ...this.vars });
        }
        continue;
      }
      if (ws[0] === 'for' && ws[1] === 'each' && ws.includes('in')) {
        const inIdx = ws.indexOf('in'), itemVar = ws[2], listName = ws[inIdx+1];
        const list = this.vars[listName] || [];
        const body = this._collectBlock();
        for (const item of list) {
          if (this.shouldReturn) break;
          this.vars[itemVar] = item; await this._runBlock(body, { ...this.vars });
        }
        continue;
      }
      await this._execLine(tokens, ws);
    }
  }

  async _execLine(tokens, ws) {
    if (ws[0] === 'say') { this.outputFn('print', this.formatVal(evalExpr(tokens.slice(1), this.vars))); return; }
    if (ws[0] === 'set' && ws.includes('to')) {
      const toIdx = ws.indexOf('to'); const varName = ws.slice(1, toIdx).join('_');
      const valTokens = tokens.slice(toIdx+1);
      const vws = valTokens.map(t => t.type === 'WORD' ? t.value.toLowerCase() : '__');
      if (vws[0] === 'run' && vws[1] === 'step') this.vars[varName] = await this._callFunction(valTokens.slice(2));
      else this.vars[varName] = evalExpr(valTokens, this.vars);
      return;
    }
    if (ws[0] === 'calculate') {
      const storeIdx = ws.indexOf('store'); let varName = null, exprTokens = tokens.slice(1);
      if (storeIdx !== -1) { varName = ws[storeIdx+2]||ws[ws.length-1]; exprTokens = tokens.slice(1, storeIdx-(ws[storeIdx-1]==='and'?1:0)); }
      const result = evalExpr(exprTokens, this.vars);
      if (varName) this.vars[varName] = result; else this.outputFn('result','= '+this.formatVal(result)); return;
    }
    if (ws[0] === 'give' && ws[1] === 'back') { this.returnValue = evalExpr(tokens.slice(2), this.vars); this.shouldReturn = true; return; }
    if (ws[0] === 'run' && ws[1] === 'step') { await this._callFunction(tokens.slice(2)); return; }
    if (ws[0] === 'create' && ws[1] === 'list') { this.vars[ws[2]] = []; return; }
    if (ws[0] === 'add' && ws.includes('to') && !ws.includes('row') && !ws.includes('table')) {
      const toIdx = ws.lastIndexOf('to'); const listName = ws[toIdx+1];
      const val = evalExpr(tokens.slice(1, toIdx), this.vars);
      if (!Array.isArray(this.vars[listName])) this.vars[listName] = [];
      this.vars[listName].push(val); return;
    }
    if (ws[0] === 'count' && ws[1] === 'of') { this.outputFn('print', this.formatVal((this.vars[ws[2]]||[]).length)); return; }
    if (ws[0] === 'item' && ws.includes('in')) {
      const inIdx = ws.indexOf('in'); const list = this.vars[ws[inIdx+1]]||[];
      this.outputFn('print', this.formatVal(list[parseInt(ws[1])-1])); return;
    }
    if (ws[0] === 'create' && ws[1] === 'table') { this.tables[ws[2]] = { headers:[], rows:[] }; return; }
    if (ws[0] === 'set' && ws[1] === 'headers') {
      const ofIdx = ws.indexOf('of'), toIdx = ws.indexOf('to'), tableName = ws[ofIdx+1];
      const headers = tokens.slice(toIdx+1).filter(t => t.type==='STRING'||(t.type==='WORD'&&t.value.toLowerCase()!=='and')).map(t=>t.value);
      if (this.tables[tableName]) this.tables[tableName].headers = headers; return;
    }
    if (ws[0] === 'add' && ws[1] === 'row') {
      const toIdx = ws.lastIndexOf('to'), tableName = ws[toIdx+1];
      const rowTokens = tokens.slice(2, toIdx); const row = []; let cur = [];
      for (const t of rowTokens) { if (t.type==='COMMA'){row.push(evalExpr(cur,this.vars));cur=[];}else cur.push(t); }
      if (cur.length) row.push(evalExpr(cur, this.vars));
      if (this.tables[tableName]) this.tables[tableName].rows.push(row); return;
    }
    if (ws[0] === 'show' && ws[1] === 'table') {
      const table = this.tables[ws[2]];
      if (!table) { this.outputFn('error', `Table "${ws[2]}" not found`); return; }
      this.outputFn('table', table); return;
    }
    if (ws[0] === 'fetch') {
      const urlToken = tokens.find(t=>t.type==='STRING');
      if (!urlToken) { this.outputFn('error','Missing URL'); return; }
      const storeIdx = ws.indexOf('store'); const varName = storeIdx !== -1 ? ws[storeIdx+2] : null;
      try {
        const resp = await fetch(urlToken.value);
        const text = await resp.text();
        if (varName) this.vars[varName] = text;
        else this.outputFn('print', text.slice(0,2000));
      } catch(e) { this.outputFn('error', 'Fetch failed: '+e.message); } return;
    }
    if (ws[0] === 'ask') {
      const question = tokens.find(t=>t.type==='STRING')?.value || 'Input: ';
      const storeIdx = ws.indexOf('store'); const varName = storeIdx !== -1 ? ws[storeIdx+2] : null;
      let answer = '';
      if (this.inputFn) answer = await this.inputFn(question);
      else { this.outputFn('prompt', '❓ '+question); answer = window.prompt(question)||''; }
      if (varName) this.vars[varName] = answer; return;
    }
    if (ws[0] === 'wait') { await new Promise(r=>setTimeout(r,(parseFloat(ws[1])||1)*1000)); return; }
    if (ws[0] === 'stop') { this.shouldReturn = true; return; }
    if (['define','end','otherwise','else'].includes(ws[0])) return;
    this.outputFn('warn', 'Unknown command: "'+ws.join(' ')+'"');
  }

  _collectBlock() {
    const body = []; let depth = 0;
    while (this.pos < this.lines.length) {
      const bl = this.lines[this.pos].trim(); const bws = bl.toLowerCase().split(/\s+/);
      if (['if','repeat','count','for','define'].includes(bws[0])) depth++;
      if (bws[0]==='end'&&bws[1]!=='step') { if(depth===0){this.pos++;break;} depth--; }
      body.push(this.lines[this.pos]); this.pos++;
    }
    return body;
  }

  async _runBlock(lines, vars) {
    const child = new PlainInterpreter({ outputFn: this.outputFn, inputFn: this.inputFn });
    child.vars = { ...vars }; child.functions = this.functions; child.tables = this.tables; child.lines = lines;
    await child.run();
    for (const k of Object.keys(child.vars)) this.vars[k] = child.vars[k];
    return child.returnValue;
  }

  async _callFunction(tokens) {
    const ws = tokens.map(t=>t.type==='WORD'?t.value.toLowerCase():'__');
    const withIdx = ws.indexOf('with');
    const funcName = withIdx !== -1 ? ws.slice(0,withIdx).join('_') : ws.join('_');
    const fn = this.functions[funcName];
    if (!fn) { this.outputFn('error',`Unknown function: "${funcName}"`); return undefined; }
    const argVals = [];
    if (withIdx !== -1) {
      let cur = [];
      for (const t of tokens.slice(withIdx+1)) {
        if (t.type==='COMMA'){argVals.push(evalExpr(cur,this.vars));cur=[];}else cur.push(t);
      }
      if (cur.length) argVals.push(evalExpr(cur,this.vars));
    }
    const localVars = { ...this.vars };
    for (let i=0; i<fn.params.length; i++) localVars[fn.params[i]] = argVals[i]!==undefined?argVals[i]:null;
    return await this._runBlock(fn.body, localVars);
  }

  async _runIf(tokens) {
    const ws = tokens.map(t=>t.type==='WORD'?t.value.toLowerCase():'__');
    const thenIdx = ws.indexOf('then');
    const condTokens = tokens.slice(1, thenIdx);
    const thenBody = [], otherwiseBranches = []; let elseBody = null, depth = 0;
    while (this.pos < this.lines.length) {
      const bl = this.lines[this.pos].trim(); const bws = bl.toLowerCase().split(/\s+/);
      if (['if','repeat','count','for'].includes(bws[0])) depth++;
      if (depth===0&&(bws[0]==='otherwise'||bws[0]==='else')) break;
      if (depth===0&&bws[0]==='end'&&bws[1]!=='step'){this.pos++;break;}
      if (bws[0]==='end'&&bws[1]!=='step') depth--;
      thenBody.push(this.lines[this.pos]); this.pos++;
    }
    while (this.pos < this.lines.length) {
      const bl = this.lines[this.pos].trim(); const bws = bl.toLowerCase().split(/\s+/);
      if (bws[0]==='end'&&bws[1]!=='step'){this.pos++;break;}
      if (bws[0]==='otherwise'||bws[0]==='else') {
        this.pos++; const isElseIf = bws.includes('if'); const body2 = [];
        if (isElseIf) {
          const lt = tokenize(bl); const lws = lt.map(t=>t.type==='WORD'?t.value.toLowerCase():'__');
          const ifIdx = lws.indexOf('if'), tIdx = lws.indexOf('then'); const cond2 = lt.slice(ifIdx+1,tIdx);
          let d2 = 0;
          while (this.pos < this.lines.length) {
            const bl3 = this.lines[this.pos].trim(); const bws3 = bl3.toLowerCase().split(/\s+/);
            if (['if','repeat','count','for'].includes(bws3[0])) d2++;
            if (d2===0&&(bws3[0]==='otherwise'||bws3[0]==='else'||(bws3[0]==='end'&&bws3[1]!=='step'))) break;
            if (bws3[0]==='end'&&bws3[1]!=='step') d2--;
            body2.push(this.lines[this.pos]); this.pos++;
          }
          otherwiseBranches.push({ cond:cond2, body:body2 });
        } else {
          let d2 = 0;
          while (this.pos < this.lines.length) {
            const bl3 = this.lines[this.pos].trim(); const bws3 = bl3.toLowerCase().split(/\s+/);
            if (['if','repeat','count','for'].includes(bws3[0])) d2++;
            if (d2===0&&bws3[0]==='end'&&bws3[1]!=='step'){this.pos++;break;}
            if (bws3[0]==='end'&&bws3[1]!=='step') d2--;
            body2.push(this.lines[this.pos]); this.pos++;
          }
          elseBody = body2; break;
        }
      } else break;
    }
    if (evalExpr(condTokens, this.vars)) { await this._runBlock(thenBody, { ...this.vars }); return; }
    for (const branch of otherwiseBranches) {
      if (evalExpr(branch.cond, this.vars)) { await this._runBlock(branch.body, { ...this.vars }); return; }
    }
    if (elseBody) await this._runBlock(elseBody, { ...this.vars });
  }
}

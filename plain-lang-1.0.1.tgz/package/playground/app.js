/**
 * PLAIN Playground — App Logic
 */

'use strict';

// ═══════════════════════════════════════════════════════════════════════════
// EXAMPLES
// ═══════════════════════════════════════════════════════════════════════════
const EXAMPLES = {
hello: `-- Hello World in PLAIN
-- Every line is a plain English instruction

say "Hello, world!"
say "Welcome to PLAIN programming."
say "You just ran your first program!"

say ""
say "Let's try some math:"
set x to 10
set y to 32
set total to x + y
say "10 + 32 = " + total`,

math: `-- Calculator: math and variables
set price to 1500
set quantity to 4
set subtotal to price * quantity
set gst_rate to 0.18
set tax to subtotal * gst_rate
set total to subtotal + tax

say "--- Invoice ---"
say "Subtotal: " + subtotal
say "GST (18%): " + tax
say "Total: " + total

-- Power and remainder
set area to 12 ^ 2
say "12 squared = " + area
set leftover to 17 % 5
say "17 divided by 5 leaves: " + leftover`,

loop: `-- Loops and Lists
create list names
add "Parth" to names
add "Vedant" to names
add "Priya" to names
add "Rahul" to names

say "All names:"
for each name in names
  say "  -> " + name
end

say ""
say "Counting from 1 to 5:"
count from 1 to 5 as n
  say "  Step " + n
end

say ""
say "Repeat 3 times:"
repeat 3 times
  say "  Working..."
end

say ""
say "Total names: " + count of names`,

conditions: `-- Conditions: if / otherwise
set score to 78

if score >= 90 then
  say "Grade: A — Excellent!"
otherwise if score >= 75 then
  say "Grade: B — Good work!"
otherwise if score >= 60 then
  say "Grade: C — Passing"
otherwise
  say "Grade: F — Needs improvement"
end

-- Multiple conditions with and/or
set age to 20
set has_id to true

if age >= 18 and has_id = true then
  say "Entry allowed"
otherwise
  say "Entry denied"
end

-- Not operator
set is_raining to false
if not is_raining then
  say "Good weather, go outside!"
end`,

functions: `-- Functions: define reusable steps

define step greet with name
  say "Hello, " + name + "! Welcome to PLAIN."
end step

define step calculate_bmi with weight, height
  set bmi to weight / (height * height)
  give back bmi
end step

define step is_even with number
  set remainder to number % 2
  if remainder = 0 then
    give back true
  otherwise
    give back false
  end
end step

-- Call the functions
run step greet with "Parth"
run step greet with "Vedant"

set my_bmi to run step calculate_bmi with 70, 1.75
say "BMI: " + my_bmi

count from 1 to 8 as i
  set even to run step is_even with i
  if even = true then
    say i + " is even"
  otherwise
    say i + " is odd"
  end
end`,

data: `-- Data Tables: spreadsheet-style

create table sales
set headers of sales to "Month", "Revenue", "Expenses", "Profit"
add row "January",  95000, 62000, 33000 to sales
add row "February", 88000, 59000, 29000 to sales
add row "March",   112000, 71000, 41000 to sales
add row "April",   125000, 68000, 57000 to sales

show table sales

-- Calculate totals
set total_rev to 95000 + 88000 + 112000 + 125000
set total_profit to 33000 + 29000 + 41000 + 57000

say ""
say "Total Revenue: " + total_rev
say "Total Profit: " + total_profit
say "Profit Margin: " + (total_profit / total_rev * 100) + "%"`,

web: `-- Web Request: fetch live data from the internet

say "Fetching Bitcoin price from the web..."

fetch "https://api.coindesk.com/v1/bpi/currentprice.json" and store in btc_data

say "Done! Raw response (first 500 chars):"
say btc_data`,

fullapp: `-- Full Mini App: Student Grade Manager

say "=== Student Grade Manager ==="
say ""

-- Set up data table
create table gradebook
set headers of gradebook to "Student", "Math", "Science", "English", "Average", "Grade"

-- Define grading function
define step get_grade with avg
  if avg >= 90 then
    give back "A"
  otherwise if avg >= 75 then
    give back "B"
  otherwise if avg >= 60 then
    give back "C"
  otherwise
    give back "F"
  end
end step

-- Define average calculator
define step avg3 with a, b, c
  give back (a + b + c) / 3
end step

-- Add students
set avg1 to run step avg3 with 92, 88, 95
set grade1 to run step get_grade with avg1
add row "Parth", 92, 88, 95, avg1, grade1 to gradebook

set avg2 to run step avg3 with 78, 82, 75
set grade2 to run step get_grade with avg2
add row "Vedant", 78, 82, 75, avg2, grade2 to gradebook

set avg3val to run step avg3 with 65, 70, 60
set grade3 to run step get_grade with avg3val
add row "Priya", 65, 70, 60, avg3val, grade3 to gradebook

set avg4 to run step avg3 with 55, 48, 62
set grade4 to run step get_grade with avg4
add row "Rahul", 55, 48, 62, avg4, grade4 to gradebook

-- Display results
show table gradebook

say ""
say "Report Summary:"
say "  Total students: 4"
say "  Class average: " + ((avg1 + avg2 + avg3val + avg4) / 4)`
};

// ═══════════════════════════════════════════════════════════════════════════
// STATE
// ═══════════════════════════════════════════════════════════════════════════
let isRunning = false;
let outputExpanded = false;
let isDirty = false;
let currentExample = 'hello';

// ═══════════════════════════════════════════════════════════════════════════
// OUTPUT RENDERER
// ═══════════════════════════════════════════════════════════════════════════
function makeOutputLine(type, value) {
  const outputEl = document.getElementById('output');

  // Remove placeholder if present
  const empty = outputEl.querySelector('.output-empty');
  if (empty) empty.remove();

  if (type === 'table') {
    const table = document.createElement('table');
    table.className = 'out-table';
    if (value.headers.length) {
      const thead = document.createElement('thead');
      const tr = document.createElement('tr');
      for (const h of value.headers) {
        const th = document.createElement('th');
        th.textContent = h;
        tr.appendChild(th);
      }
      thead.appendChild(tr);
      table.appendChild(thead);
    }
    const tbody = document.createElement('tbody');
    for (const row of value.rows) {
      const tr = document.createElement('tr');
      for (const cell of row) {
        const td = document.createElement('td');
        td.textContent = typeof cell === 'number' ? (Number.isInteger(cell) ? cell : parseFloat(cell.toFixed(4))) : (cell ?? '');
        tr.appendChild(td);
      }
      tbody.appendChild(tr);
    }
    table.appendChild(tbody);
    outputEl.appendChild(table);
  } else {
    const div = document.createElement('div');
    div.className = `ol ol-${type}`;
    if (type === 'warn') value = '⚠ ' + value;
    if (type === 'error') value = '✖ ' + value;
    div.textContent = value;
    outputEl.appendChild(div);
  }

  outputEl.scrollTop = outputEl.scrollHeight;
}

// ═══════════════════════════════════════════════════════════════════════════
// RUN CODE
// ═══════════════════════════════════════════════════════════════════════════
async function runCode() {
  if (isRunning) return;
  isRunning = true;

  const code = document.getElementById('editor').value;
  const badge = document.getElementById('statusBadge');
  const runBtn = document.getElementById('runBtn');

  // Clear output
  document.getElementById('output').innerHTML = '';
  badge.className = 'output-status status-running';
  badge.textContent = 'Running…';
  runBtn.classList.add('running');

  const t0 = Date.now();

  try {
    const interp = new PlainInterpreter({ outputFn: makeOutputLine });
    await interp.run(code);
    const ms = Date.now() - t0;
    badge.className = 'output-status status-ok';
    badge.textContent = `Done ✓ ${ms}ms`;
  } catch (e) {
    makeOutputLine('error', 'Runtime error: ' + e.message);
    badge.className = 'output-status status-err';
    badge.textContent = 'Error';
  }

  runBtn.classList.remove('running');
  isRunning = false;
}

function clearOutput() {
  const outputEl = document.getElementById('output');
  outputEl.innerHTML = `
    <div class="output-empty">
      <div class="empty-icon">▶</div>
      <div>Press <kbd>Run Program</kbd> or <kbd>Ctrl+Enter</kbd></div>
    </div>`;
  const badge = document.getElementById('statusBadge');
  badge.className = 'output-status status-idle';
  badge.textContent = 'Ready';
}

function toggleOutputSize() {
  const panel = document.getElementById('outputPanel');
  outputExpanded = !outputExpanded;
  panel.classList.toggle('expanded', outputExpanded);
}

// ═══════════════════════════════════════════════════════════════════════════
// EDITOR
// ═══════════════════════════════════════════════════════════════════════════
function updateLineNumbers() {
  const editor = document.getElementById('editor');
  const lnEl = document.getElementById('lineNums');
  const count = editor.value.split('\n').length;
  const existing = lnEl.children.length;

  if (count > existing) {
    for (let i = existing + 1; i <= count; i++) {
      const span = document.createElement('span');
      span.className = 'line-num';
      span.textContent = i;
      lnEl.appendChild(span);
    }
  } else if (count < existing) {
    while (lnEl.children.length > count) lnEl.removeChild(lnEl.lastChild);
  }
}

function syncScroll() {
  const editor = document.getElementById('editor');
  const lnEl = document.getElementById('lineNums');
  lnEl.scrollTop = editor.scrollTop;
}

function updateCursor() {
  const editor = document.getElementById('editor');
  const text = editor.value.substring(0, editor.selectionStart);
  const lines = text.split('\n');
  const line = lines.length;
  const col = lines[lines.length - 1].length + 1;
  document.getElementById('lineColInfo').textContent = `Ln ${line}, Col ${col}`;
}

function onEditorInput() {
  updateLineNumbers();
  updateCursor();
  // mark as unsaved
  if (!isDirty) {
    isDirty = true;
    document.getElementById('unsaved-dot').style.display = 'block';
  }
}

function handleKey(e) {
  // Tab — insert 2 spaces
  if (e.key === 'Tab') {
    e.preventDefault();
    const el = e.target;
    const s = el.selectionStart;
    el.value = el.value.substring(0, s) + '  ' + el.value.substring(el.selectionEnd);
    el.selectionStart = el.selectionEnd = s + 2;
    updateLineNumbers();
    return;
  }
  // Ctrl+Enter — run
  if ((e.ctrlKey || e.metaKey) && e.key === 'Enter') {
    e.preventDefault();
    runCode();
    return;
  }
  // Auto-close quotes
  if (e.key === '"') {
    const el = e.target;
    const s = el.selectionStart;
    const after = el.value[s];
    if (after !== '"') {
      e.preventDefault();
      el.value = el.value.substring(0, s) + '""' + el.value.substring(el.selectionEnd);
      el.selectionStart = el.selectionEnd = s + 1;
      updateLineNumbers();
    }
  }
}

// ═══════════════════════════════════════════════════════════════════════════
// EXAMPLE LOADER
// ═══════════════════════════════════════════════════════════════════════════
function loadExample(name, btn) {
  const code = EXAMPLES[name];
  if (!code) return;
  document.getElementById('editor').value = code.trim();
  updateLineNumbers();
  updateCursor();
  isDirty = false;
  document.getElementById('unsaved-dot').style.display = 'none';
  document.getElementById('filename').textContent = name + '.plain';
  clearOutput();
  currentExample = name;

  // Update active state
  document.querySelectorAll('.ex-btn').forEach(b => b.classList.remove('active'));
  if (btn) btn.classList.add('active');
}

// ═══════════════════════════════════════════════════════════════════════════
// TAB SWITCHING
// ═══════════════════════════════════════════════════════════════════════════
function switchTab(tab) {
  const editorTab = document.getElementById('tab-editor');
  const docsTab = document.getElementById('tab-docs');
  const workspace = document.getElementById('workspace');
  const docsPanel = document.getElementById('docs-panel');

  if (tab === 'editor') {
    editorTab.classList.add('active');
    docsTab.classList.remove('active');
    workspace.style.display = 'flex';
    docsPanel.style.display = 'none';
  } else {
    editorTab.classList.remove('active');
    docsTab.classList.add('active');
    workspace.style.display = 'none';
    docsPanel.style.display = 'block';
  }
}

// ═══════════════════════════════════════════════════════════════════════════
// NAVIGATION
// ═══════════════════════════════════════════════════════════════════════════
function showApp() {
  document.getElementById('landing').style.display = 'none';
  const app = document.getElementById('app');
  app.style.display = 'flex';
  document.body.style.overflow = 'hidden';
}

function showLanding() {
  document.getElementById('app').style.display = 'none';
  const landing = document.getElementById('landing');
  landing.style.display = 'block';
  document.body.style.overflow = '';
}

// ═══════════════════════════════════════════════════════════════════════════
// UTILITIES
// ═══════════════════════════════════════════════════════════════════════════
function formatCode() {
  const editor = document.getElementById('editor');
  const lines = editor.value.split('\n');
  const indent = { if: 1, repeat: 1, count: 1, for: 1, define: 1, otherwise: 0, end: -1 };
  let level = 0, result = [];
  for (const line of lines) {
    const trimmed = line.trim();
    if (!trimmed) { result.push(''); continue; }
    const first = trimmed.toLowerCase().split(/\s+/)[0];
    if (first === 'end' || first === 'otherwise') level = Math.max(0, level - 1);
    result.push('  '.repeat(level) + trimmed);
    if (['if','repeat','count','for','define','otherwise'].includes(first) && !trimmed.toLowerCase().endsWith('end')) {
      level++;
    }
  }
  editor.value = result.join('\n');
  updateLineNumbers();
  showToast('Code formatted!');
}

function shareCode() {
  const code = document.getElementById('editor').value;
  const encoded = btoa(encodeURIComponent(code));
  const url = window.location.origin + window.location.pathname + '?code=' + encoded;
  navigator.clipboard.writeText(url).then(() => showToast('Link copied to clipboard!')).catch(() => {
    showToast('Share URL: ' + url.slice(0, 60) + '…');
  });
}

function copyCmd(el) {
  const text = el.querySelector('.cmd-text').textContent;
  navigator.clipboard.writeText(text).then(() => {
    const copyEl = el.querySelector('.cmd-copy');
    copyEl.textContent = 'Copied!';
    setTimeout(() => (copyEl.textContent = 'Copy'), 1500);
  });
}

function showToast(msg) {
  const t = document.getElementById('toast');
  t.textContent = msg;
  t.classList.add('show');
  clearTimeout(t._timer);
  t._timer = setTimeout(() => t.classList.remove('show'), 2500);
}

// ─── Load from URL ────────────────────────────────────────────────────────
function loadFromURL() {
  try {
    const params = new URLSearchParams(window.location.search);
    const code = params.get('code');
    if (code) {
      document.getElementById('editor').value = decodeURIComponent(atob(code));
      updateLineNumbers();
      showApp();
    }
  } catch {}
}

// ═══════════════════════════════════════════════════════════════════════════
// INIT
// ═══════════════════════════════════════════════════════════════════════════
window.addEventListener('load', () => {
  loadExample('hello', document.getElementById('ex-hello'));
  loadFromURL();

  // Handle browser resize for line numbers
  const ro = new ResizeObserver(updateLineNumbers);
  ro.observe(document.getElementById('editor'));
});

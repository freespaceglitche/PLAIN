# PLAIN Language Support for VS Code

This extension provides syntax highlighting for the PLAIN programming language (`.plain` files).

## Installation (Local Development)

1. Open a terminal in this `vscode-extension` folder.
2. Run `npm install -g @vscode/vsce` (if you don't have vsce installed).
3. Run `vsce package` to generate a `.vsix` file.
4. In VS Code, go to **Extensions**.
5. Click the `...` menu in the top right of the Extensions view.
6. Select **Install from VSIX...** and select the `.vsix` file you just generated.

## Features
- Syntax highlighting for all PLAIN keywords (say, ask, if, count from, define step, etc.)
- Highlights strings, numbers, and operators
- Formats `--` code comments beautifully

## Publishing (Optional)
If you want to publish your language extension to the VS Code Marketplace, you can read the [official guide here](https://code.visualstudio.com/api/working-with-extensions/publishing-extension).
